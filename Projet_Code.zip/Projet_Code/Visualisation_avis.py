import streamlit as st
import pandas as pd
import psycopg2

# Etablir la connexion à la base de données PostgreSQL
def create_db_connection():
    connection = psycopg2.connect( 
        host="localhost",
        database="ESILVision",
        user="postgres",
        password="zaL2520"
    )
    return connection

#Fonction pour récupérer l'avis sur les profs
def get_avis_prof():
    connection = create_db_connection()
    query = "SELECT * FROM avis_prof;"
    student_data = pd.read_sql_query(query, connection)
    connection.close()
    return student_data

#Fonction pour récupérer l'avis sur les cours
def get_avis_cours():
    connection = create_db_connection()
    query = "SELECT * FROM avis_course;"
    student_data = pd.read_sql_query(query, connection)
    connection.close()
    return student_data

def main():
    st.title("Avis sur les Professeurs et les Cours")

    prof_avis = get_avis_prof()
    cours_avis = get_avis_cours()

    st.header("Avis des Professeurs :")

    profs = prof_avis['email'].unique() #permet d'afficher les avis par professeurs
    for prof in profs:
        avis_prof = prof_avis[prof_avis['email'] == prof]['avis']
        st.subheader(f"{prof} :")
        for avis in avis_prof:
            st.write(f"   {avis}")


    st.header("Avis des Cours :")

    cours = cours_avis['cours'].unique() #permet d'afficher les avis par cours
    for cours_title in cours:
        avis_cours = cours_avis[cours_avis['cours'] == cours_title]['avis']
        st.subheader(f"{cours_title} :")
        for avis in avis_cours:
            st.write(f"   {avis}")

if __name__ == "__main__":
    main()



