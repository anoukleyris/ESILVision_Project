import streamlit as st
import pandas as pd
import psycopg2
from sqlalchemy import create_engine
import matplotlib.pyplot as plt

# Etablir la connexion à la base de données PostgreSQL
def create_db_connection():
    connection = psycopg2.connect( 
        host="localhost",
        database="ESILVision",
        user="postgres",
        password="zaL2520"
    )
    return connection

# Fontion pour récupérer toutes les informations des documents d'un étudiant
def get_document(id):
    connection = create_db_connection()
    query = f"SELECT * FROM pdf_documents WHERE etudiant_id={id};"
    document_data = pd.read_sql_query(query, connection)
    connection.close()
    return document_data

# Fontion pour récupérer toutes les informations d'un étudiant
def get_student_data_by_id(id): 
    connection = create_db_connection()
    query = f"SELECT * FROM etudiants WHERE id = '{id}';" 
    student_data = pd.read_sql_query(query, connection)
    connection.close()
    return student_data

# Fontion pour récupérer toutes les notes d'un étudiant
def get_student_notes_by_id(id):
    connection = create_db_connection()
    query = f"SELECT numero_controle, cours_title, note, coefficient FROM public.notes WHERE etudiant_id = {id};"
    notes_data = pd.read_sql_query(query, connection)
    connection.close()
    return notes_data

# Fontion pour afficher les notes dans des graphes 
def show_notes_chart(notes_data):
    unique_courses = notes_data['cours_title'].unique()#permet de faire un graphe pour chaque matière

    for course in unique_courses: 
        course_data = notes_data[notes_data['cours_title'] == course]

        fig, ax = plt.subplots()
        ax.plot(course_data['numero_controle'], course_data['note'], marker='o', linestyle='-', color='b') #en abscisse : le numero du contrôle, en ordonnée : les notes
        ax.set_xlabel('Numéro de Contrôle')
        ax.set_ylabel('Note')
        ax.set_title(f'Notes de l\'élève pour le cours {course}')

        ax.set_xticks(course_data['numero_controle'])

        st.pyplot(fig)

#Affiche le tableu des détails notes 
def show_notes_table(notes_data):
    unique_courses = notes_data['cours_title'].unique()#permet de faire un tableau pour chaque matière

    for course in unique_courses:
        st.subheader(f'Matière: {course}')

        course_data = notes_data[notes_data['cours_title'] == course]
        course_data = course_data.sort_values(by='numero_controle')

        st.table(course_data[['numero_controle', 'note', 'coefficient']].reset_index(drop=True))

        average = course_data['note'].mean()#on ajoute la moyenne des notes par matière
        
        st.write(f'Moyenne pour {course}: {average:.2f}')   


def main(id):
    result_data = get_student_data_by_id(id)
    st.table(result_data)
    
    prenom = result_data.iloc[0]['prenom']
    nom = result_data.iloc[0]['nom']
    
    document_data = get_document(id)
    st.title(f"Profil de {prenom} {nom}")
    st.title(f"Documents de {prenom} {nom}")
    
    # Ajouter la colonne avec les liens vers les fichiers PDF
    st.markdown("### Liens vers les fichiers PDF en ligne :")
    for index, row in document_data.iterrows():
        pdf_link = f"{row['file_path']}"
        st.markdown(pdf_link, unsafe_allow_html=True)
    
    notes_data = get_student_notes_by_id(id)
    st.title(f"Progression de {prenom} {nom}")
    show_notes_chart(notes_data)
    show_notes_table(notes_data)            


if __name__ == "__main__":
    main(id)
