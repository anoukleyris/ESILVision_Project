import streamlit as st
import pandas as pd
import psycopg2

# Etablir la connexion à la base de données PostgreSQL
def create_db_connection():
    connection = psycopg2.connect( 
        host="localhost",
        database="ESILVision",
        user="postgres",
        password="zaL2520"
    )
    return connection

#Fonction pour récupérer toute les informations des cours
def get_cours(): 
    connection = create_db_connection()
    query = "SELECT * FROM cours;" 
    cours_data = pd.read_sql_query(query, connection)
    connection.close()
    return cours_data

#Fonction pour récupérer toute les notes d'un cours
def get_note_by_cours(cours): 
    connection = create_db_connection()
    query = f"SELECT * FROM notes WHERE cours_title = '{cours}';" 
    notes_data = pd.read_sql_query(query, connection)
    connection.close()
    return notes_data

#Fonction pour modifier les lignes de la table notes
def modify_note(note, note_id):
    connection = create_db_connection()
    cursor = connection.cursor()

    cursor.execute("""
        UPDATE notes
        SET note = %s
        WHERE id = %s;
    """, (note, note_id))

    connection.commit()
    connection.close()

#Fonction pour supprimer les lignes de la table notes
def delete_note_by_id(note_id):
    connection = create_db_connection()
    cursor = connection.cursor()

    cursor.execute(f"DELETE FROM public.notes WHERE id = {note_id};")
    connection.commit()
    connection.close()

def main():
    st.title("Notes par matière")

    cours = get_cours()

    for title in cours['title']:
        st.subheader(f"Notes pour le cours {title}")
        cours_data = get_note_by_cours(title)
        st.table(cours_data)

    st.title("Modification de notes")

    note = st.text_input('NOUVELLE NOTE:')
    note_id = st.text_input('ID DE NOTE:')
    modify_button = st.button('Modifier la note')

    if modify_button and note and note_id:
        modify_note(note, note_id)
        st.success("Note modifiée avec succès")
        st.experimental_rerun()

    st.title("Suppression de notes")

    note_id_a_supprimer = st.text_input("Entrer l'ID de la note à supprimer")
    delete_button = st.button('Supprimer')

    if delete_button and note_id_a_supprimer:
        delete_note_by_id(note_id_a_supprimer)
        st.success("Note supprimée avec succès")
        st.experimental_rerun()

if __name__ == "__main__":
    main()

