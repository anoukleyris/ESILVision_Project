import streamlit as st
import pandas as pd
import psycopg2
from sqlalchemy import create_engine

# Etablir la connexion à la base de données PostgreSQL
def create_db_connection():
    connection = psycopg2.connect( 
        host="localhost",
        database="ESILVision",
        user="postgres",
        password="zaL2520"
    )
    return connection

#Récupère les information de l'étudiant
def get_student_data_by_id(id): 
    connection = create_db_connection()
    query = f"SELECT * FROM etudiants WHERE id = '{id}';" 
    student_data = pd.read_sql_query(query, connection)
    connection.close()
    return student_data

def main(id):
    etudiant = get_student_data_by_id(id)
    st.table(etudiant)

if __name__ == "__main__":
    main(id)
