import streamlit as st
from reportlab.pdfgen import canvas
from datetime import date
import os

def create_pdf(student_id, specialite, prenom, nom):
    directory = "/Users/anoukleyris/Documents/4ème année ESILV /Software engineering/Projet/Documents élèves"
    if not os.path.exists(directory):
        os.makedirs(directory)

    filename = f"diploma_{student_id}.pdf"
    filepath = os.path.join(directory, filename)

    # Création du PDF avec ReportLab
    with open(filepath, 'w+b') as f:
        c = canvas.Canvas(f)
        c.setFont("Helvetica-Bold", 24)  
        
        # Obtenir la hauteur de la page
        height = c._pagesize[1]

        # Calculer la position verticale du centre
        center_vertical = height / 2

        # Dessiner le titre centré verticalement
        c.drawCentredString(300, 800, f"Diplôme d'ingénieur spécialisé en {specialite}")

        c.setFont("Helvetica", 14) 

        text_lines = [
            "Monsieur Pascal Pinot, directeur de l'Ecole supérieure d'ingénieurs Léonard De Vinci,",
            f"certifie que {prenom} {nom} est désormais diplômé ingénieur généraliste de l'ESILV"
        ]

        text_height = 14  # Hauteur du texte principal
        text_position = center_vertical - (len(text_lines) * text_height / 2) #Position du texte principal

        for line in text_lines:
            c.drawCentredString(300, text_position, line)
            text_position -= text_height 

        # Fait à Paris, le (date du jour)
        today = date.today()
        formatted_date = today.strftime("%d/%m/%Y")
        fait_a_paris = f"Fait à Paris, le {formatted_date}"
        c.drawRightString(580, 50, fait_a_paris)  # Position en bas à droite

        c.save()

    return filename, filepath

def main():
    st.title("Génération de Certificat de Diplôme")

    st.header("Ajouter des Détails de Diplôme")
    student_id = st.text_input("Identifiant de l'étudiant:")
    prenom = st.text_input("Prénom de l'étudiant:")
    nom = st.text_input("Nom de l'étudiant:")
    specialite = st.text_input("Spécialité:")

    add_button = st.button("Ajouter le Diplôme et Générer le Certificat")

    if add_button:
        pdf_filename, pdf_filepath = create_pdf(student_id, specialite, prenom, nom)

        st.success(f"Certificat de diplôme généré: [{pdf_filename}]")
        st.text("Chemin du Certificat de Diplôme:")
        st.text(pdf_filepath)

if __name__ == "__main__":
    main()
