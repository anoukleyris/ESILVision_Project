import streamlit as st
from Liste_etudiants import main as liste_etudiants_main
from Calendrier import main as calendrier_main
from Liste_cours import main as liste_cours_main
from Liste_prof import main as liste_prof_main
from Profil_etudiants import main as profil_etudiants_main
from Selection_par_id import main as liste_eleve_main
from Notes import main as notes_main
from Profil import main as profil_main
from avis import main as avis_main
from Visualisation_avis import main as visualisation_avis_main
from Selection_par_email import main as liste_professeur_main
from Diplomes import main as diplome_main
from Documents_etudiants import main as documents_etudiants_main
from Absences import main as absences_main
from Message import main as message_main
from Visualisation_message import main as visualisation_message_main
import psycopg2

# Etablir la connexion à la base de données PostgreSQL
def create_db_connection():
    connection = psycopg2.connect( 
        host="localhost",
        database="ESILVision",
        user="postgres",
        password="zaL2520"
    )
    return connection

def authenticate():
    if 'authenticated' not in st.session_state:
        st.session_state['authenticated'] = None

    st.title("ESILVision App - Connexion")

    username = st.text_input("Nom d'utilisateur") #entrer le nom utilisateur
    password = st.text_input("Mot de passe", type="password") #entrer le mot de passe

    role = st.radio("Choisissez votre rôle", ["Etudiant", "Administrateur", "Parent"])#choix du rôle

    submit_button = st.button("S'authentifier")#bouton sur lequel on appuie pour s'authentifier

    if submit_button: #si on clique sur le bouton
        connection = create_db_connection() #connexion à la base de données
        cursor = connection.cursor()

        if role == "Administrateur": #si le rôle est administraeur 
            if username == "admin" and password == "passwordadmin123": #et que les informations entrées sont bonnes
                # Authentification réussie pour l'administrateur
                st.success("Authentification réussie en tant qu'administrateur.") 
                st.session_state['authenticated'] = {"role": "admin"} #authentification en tant qu'admin
            else:
                st.warning("Identifiants incorrects pour l'administrateur.")

        elif role == "Etudiant": #si le rôle est étudiant 
            cursor.execute("""
                SELECT id, mot_de_passe
                FROM public.etudiants
                WHERE nom = %s AND mot_de_passe = %s;
            """, (username, password)) #on récupère les infos de l'exécution de la requête dans la base de données 
            result = cursor.fetchone() #on récupère la première ligne de résultat (il ne peut que y en avoir une car le mot de passe est unique)

            if result: #si on a récupéré une ligne
                student_id, _ = result
                st.success("Authentification réussie en tant qu'étudiant.") 
                st.session_state['authenticated'] = {"role": "etudiant", "id": student_id} #authentification en tant qu'étudiant et on récupère l'id qui nous sera utile
            else:
                st.warning("Identifiants incorrects pour l'étudiant.")
        else : #si le rôle est parent -> même fonctionnement que pour les étudiants
            cursor.execute("""
                SELECT student_id, mot_de_passe
                FROM public.parent
                WHERE nom = %s AND mot_de_passe = %s;
            """, (username, password))
            result = cursor.fetchone()

            if result:
                student_id, _ = result
                st.success("Authentification réussie en tant qu'étudiant.")
                st.session_state['authenticated'] = {"role": "parent", "id": student_id}
            else:
                st.warning("Identifiants incorrects pour le parent.")
            

        connection.close()

    # Retourner l'état d'authentification actuel
    return st.session_state['authenticated']


def main():
    # Vérifier si l'utilisateur est déjà authentifié
    if 'authenticated' not in st.session_state or st.session_state['authenticated'] is None:
        auth_result = authenticate()
    else:
        auth_result = st.session_state['authenticated']

    # Rôle admin
    if auth_result and auth_result["role"] == "admin":
        st.sidebar.title("Navigation")
        selected_page = st.sidebar.radio("", ["Calendrier", "Liste des Étudiants", "Liste des cours", "Liste des Professeur", "Profil étudiant", "Elèves par classe", "Notes", "Avis", "Professeurs par cours", "Diplome", "Absences", "Messagerie"]) #toutes les sections
        if selected_page == "Calendrier":
            calendrier_main()
        elif selected_page == "Liste des Étudiants":
            liste_etudiants_main()
        elif selected_page == "Liste des cours":
            liste_cours_main()
        elif selected_page == "Liste des Professeur":
            liste_prof_main()
        elif selected_page == "Profil étudiant":
            profil_etudiants_main()
        elif selected_page == "Elèves par classe":
            liste_eleve_main()
        elif selected_page == "Notes":
            notes_main()
        elif selected_page == "Avis":
            visualisation_avis_main()
        elif selected_page == "Professeurs par cours":
            liste_professeur_main()
        elif selected_page == "Diplome":
            diplome_main()
        elif selected_page == "Absences":
            absences_main()
        elif selected_page == "Messagerie":
            message_main()
    # Rôle etudiant
    elif auth_result and auth_result["role"] == "etudiant":
        student_id = auth_result["id"]
        st.sidebar.title("Navigation")
        selected_page = st.sidebar.radio("", ["Profil étudiant", "Donner son avis", "Documents personnels", "Messagerie"]) #toutes les sections
        if selected_page == "Profil étudiant":
            profil_main(student_id)
        elif selected_page == "Donner son avis":
            avis_main()
        elif selected_page == "Documents personnels":
            documents_etudiants_main(student_id)
        elif selected_page == "Messagerie":
            visualisation_message_main(student_id)
    # Rôle parent
    elif auth_result and auth_result["role"] == "parent":
        student_id = auth_result["id"]
        st.sidebar.title("Navigation")
        selected_page = st.sidebar.radio("", ["Profil étudiant"]) #toutes les sections
        if selected_page == "Profil étudiant":
            profil_main(student_id)

    else:
        st.warning("Veuillez vous connecter pour accéder à l'application.")

if __name__ == "__main__":
    main()


