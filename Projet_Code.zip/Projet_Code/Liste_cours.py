import streamlit as st
import pandas as pd
import psycopg2
from sqlalchemy import create_engine

# Etablir la connexion à la base de données PostgreSQL
def create_db_connection():
    connection = psycopg2.connect( 
        host="localhost",
        database="ESILVision",
        user="postgres",
        password="zaL2520"
    )
    return connection

#Fonction pour récupérer toutes les informations des cours
def get_cours_data_from_db():
    connection = create_db_connection()
    query = "SELECT * FROM cours;"  
    cours_data = pd.read_sql_query(query, connection)
    connection.close()
    return cours_data

#Fonction pour créer un nouveau cours dans la base de données
def add_cours_data_to_db(new_data):
    connection = create_db_connection()
    cursor = connection.cursor()   
    for index, row in new_data.iterrows():    
        cursor.execute("""
            INSERT INTO cours (title, description, start_date, end_date, number_hours)
            VALUES (%s, %s, %s, %s, %s)
        """, (row["TITLE"], row["DESCRIPTION"], row["START_DATE"], row["END_DATE"], row["NUMBER_HOURS"]))

    connection.commit()
    connection.close()

#Fonction pour supprimer un cours de la base de données
def delete_cours_by_title(title):
    connection = create_db_connection()
    cursor = connection.cursor()
    cursor.execute(f"DELETE FROM cours WHERE title = '{title}';")
    connection.commit()
    connection.close()
    

def main():
    st.title("Liste des Cours")

    cours_data = get_cours_data_from_db()

    st.table(cours_data)
    
    st.title("Ajout de cours")

    title = st.text_input('TITLE:')
    description = st.text_input('DESCRIPTION:')
    start_date = st.text_input('START_DATE:')
    end_date = st.text_input('END_DATE:')
    number_hours = st.text_input('NUMBER_HOURS:')
    add_button = st.button('Ajouter')

    if add_button:
        new_data = pd.DataFrame({
            "TITLE": [title],
            "DESCRIPTION": [description],
            "START_DATE": [start_date],
            "END_DATE": [end_date],
            "NUMBER_HOURS": [number_hours],
        })

        add_cours_data_to_db(new_data)
        st.success('Cours ajouté avec succès!')
        st.experimental_rerun()
        
    st.title("Suppression de cours")
    
    cours_a_supprimer = st.text_input("Entrer le titre du cours à supprimer")
    add_button2 = st.button('Supprimer')
    
    if add_button2 : 
        delete_cours_by_title(cours_a_supprimer)
        st.success("Cours supprimé avec succès")
        st.experimental_rerun()
    
    
if __name__ == "__main__":
    main()
