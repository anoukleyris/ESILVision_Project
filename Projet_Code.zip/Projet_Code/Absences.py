import streamlit as st
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
import psycopg2

# Etablir la connexion à la base de données PostgreSQL
def create_db_connection():
    connection = psycopg2.connect( 
        host="localhost",
        database="ESILVision",
        user="postgres",
        password="zaL2520"
    )
    return connection

#Fonction pour récupérer la date et la raison de l'absence de l'étudiant
def get_absences(id):
    connection = create_db_connection()
    query = f"SELECT report_date, absence_reason FROM absence_reports WHERE student_id = {id};"
    student_data = pd.read_sql_query(query, connection)
    connection.close()
    return student_data

#Fonction pour récupérer le prénom et le nom de l'étudiant
def get_nom_prenom(id):
    connection = create_db_connection()
    query = f"SELECT prenom || ' ' || nom AS full_name FROM public.etudiants WHERE id= {id};"
    student_data = pd.read_sql_query(query, connection)
    connection.close()
    return student_data

def main():
    st.title("Affichage des Absences par Élève")

    recherche = st.text_input('Recherche par ID')
    add_button = st.button('Rechercher')

    if add_button:
        if recherche:  
            absences_data = get_absences(recherche)

            if not absences_data.empty:
                nom_prenom = get_nom_prenom(recherche)['full_name'].iloc[0]
                
                st.subheader(f"Absences de {nom_prenom}")

                st.table(absences_data)
                
                fig = go.Figure() #création d'un emplacement pour le graphe

                for index, row in absences_data.iterrows():
                    fig.add_trace(go.Scatter(
                        x=[row['report_date']], #en absisse : les dates
                        y=[1], #en ordonnée : présent ou absent
                        mode='markers', # sytème de crois pour marquer les absences
                        marker=dict(color='red', symbol='cross'),
                        hovertext=[f"Absent le {row['report_date']} - Raison: {row['absence_reason']}"], #légende pour chaque point
                        hoverinfo='text',
                    ))

                fig.update_layout( #ajout des titres et des légendes
                    title=f'Absences de {nom_prenom}',
                    xaxis_title='Date',
                    yaxis_title='Présence',
                    yaxis=dict(tickvals=[0, 1], ticktext=['Présent', 'Absent']),
                    showlegend=False 
                )

                st.plotly_chart(fig) # Affichage du graphique

            else:
                st.warning(f"Aucune absence enregistrée pour l'élève avec l'identifiant {recherche}.")
        else:
            st.warning("Veuillez entrer un ID pour effectuer la recherche.")


if __name__ == "__main__":
    main()

