import streamlit as st
import pandas as pd
import psycopg2
from sqlalchemy import create_engine

# Etablir la connexion à la base de données PostgreSQL
def create_db_connection():
    connection = psycopg2.connect( 
        host="localhost",
        database="ESILVision",
        user="postgres",
        password="zaL2520"
    )
    return connection

#Fonction pour récupérer toutes les informations sur les professeurs
def get_prof_data_from_db():
    connection = create_db_connection() 
    query = "SELECT * FROM prof;" 
    student_data = pd.read_sql_query(query, connection) 
    connection.close()
    return student_data


#Fonction pour récupérer toutes les informations d'un professeur
def get_prof_data_by_id(email): 
    connection = create_db_connection()
    query = f"SELECT * FROM public.prof WHERE email = '{email}';"
    student_data = pd.read_sql_query(query, connection)
    connection.close()
    return student_data


#Fonction pour ajouter un professeur à la base de données 
def add_prof_data_to_db(new_data):
    connection = create_db_connection()
    cursor = connection.cursor() 

    for index, row in new_data.iterrows():
        cursor.execute("""
            INSERT INTO prof (email, nom, prenom, cours_title)
            VALUES (%s, %s, %s, %s)
        """, (row["EMAIL"], row["NOM"], row["PRENOM"], row["MATIERE"]))

    connection.commit()
    connection.close()
    

#Fonction pour supprmier un professeur à la base de données 
def delete_prof_by_id(email):
    connection = create_db_connection()
    cursor = connection.cursor()

    cursor.execute(f"DELETE FROM prof WHERE email = '{email}';")
    connection.commit()
    connection.close()


def main():
    st.title("Liste des Professeurs")

    prof_data = get_prof_data_from_db()

    st.table(prof_data)
    
    recherche = st.text_input('Recherche par EMAIL')
    add_button = st.button('Rechercher')

    if add_button:
        if recherche:  
            result_data = get_prof_data_by_id(recherche)
            st.table(result_data)
        else:
            st.warning("Veuillez entrer un email pour effectuer la recherche.")
            
    st.title("Ajout de professeurs")

    email = st.text_input('EMAIL:')
    nom = st.text_input('NOM:')
    prenom = st.text_input('PRENOM:')
    cours_title = st.text_input('MATIERE:')
    add_button2 = st.button('Ajouter')

    if add_button2:
        new_data = pd.DataFrame({
            "EMAIL": [email],
            "NOM": [nom],
            "PRENOM": [prenom],
            "MATIERE": [cours_title],
        })
        add_prof_data_to_db(new_data)
        st.success("Professeur ajouté avec succès")
        st.experimental_rerun()
        
    st.title("Suppression de professeur")
    
    email_a_supprimer = st.text_input("Entrer l'email du professeur à supprimer")
    add_button3 = st.button('Supprimer')
    
    if add_button3 : 
        delete_prof_by_id(email_a_supprimer)
        st.success("Professeur supprimé avec succès")
        st.experimental_rerun()


if __name__ == "__main__":
    main()


