import streamlit as st
import pandas as pd
import psycopg2
from sqlalchemy import create_engine

# Etablir la connexion à la base de données PostgreSQL
def create_db_connection():
    connection = psycopg2.connect( 
        host="localhost",
        database="ESILVision",
        user="postgres",
        password="zaL2520"
    )
    return connection

def get_document_path(id):
    connection = create_db_connection()
    query = f"SELECT filename, filepath FROM document_eleve WHERE student_id={id};"
    document_data = pd.read_sql_query(query, connection)
    connection.close()
    return document_data

def add_document(path):
    connection = create_db_connection()
    cursor = connection.cursor()

    for index, row in path.iterrows():
        cursor.execute(f"""
            INSERT INTO document_eleve (student_id, filename, filepath)
            VALUES (%s, %s, %s)
        """, (row["STUDENT ID"], row["FILENAME"], row["FILEPATH"]))

    connection.commit()
    connection.close()


def main(id):
    st.title("Documents personnels de l'élève")

    document = get_document_path(id)

    # Concaténer les colonnes 'filename' et 'filepath' avec ': '
    document['combined'] = document.apply(lambda row: f"**{row['filename']}** : {row['filepath']}", axis=1)

    # Afficher la liste
    for combined_text in document['combined']:
        st.write(combined_text, unsafe_allow_html=True)
    
    st.title("Insérer un nouveau document")

    student_id = id
    filename = st.text_input('FILENAME:')
    filepath = st.text_input('FILEPATH:')
    add_button = st.button('Ajouter')

    if add_button:
        new_data = pd.DataFrame({
            "STUDENT ID" : [student_id],
            "FILENAME": [filename],
            "FILEPATH": [filepath] 
        })
        add_document(new_data)
        st.success("Document ajouté !")
        st.experimental_rerun()

if __name__ == "__main__":
    main()
