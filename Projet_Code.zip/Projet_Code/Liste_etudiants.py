import streamlit as st
import pandas as pd
import psycopg2
from sqlalchemy import create_engine

# Etablir la connexion à la base de données PostgreSQL
def create_db_connection():
    connection = psycopg2.connect( 
        host="localhost",
        database="ESILVision",
        user="postgres",
        password="zaL2520"
    )
    return connection

#Fonction pour récupérer toutes les informations sur les étudiants
def get_student_data_from_db():
    connection = create_db_connection() 
    query = "SELECT * FROM etudiants;" 
    student_data = pd.read_sql_query(query, connection) 
    connection.close()
    return student_data

#Fonction pour récupérer toutes les informations d'un étudiant
def get_student_data_by_id(id): 
    connection = create_db_connection()
    query = f"SELECT * FROM etudiants WHERE id = '{id}';" 
    student_data = pd.read_sql_query(query, connection)
    connection.close()
    return student_data

#Fonction pour ajouter un étudiant à la base de données et ainsi ajouter un parent à la base de données
def add_student_data_to_db(new_data):
    connection = create_db_connection()
    cursor = connection.cursor()

    for index, row in new_data.iterrows():
        cursor.execute("""
            INSERT INTO etudiants (nom, prenom, date_naissance, ville_naissance, adresse_postale, numero_telephone, contact_urgence_nom, contact_urgence_telephone, classe, specialisation)
            VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
            RETURNING id
        """, (row["NOM"], row["PRENOM"], row["DATE DE NAISSANCE"], row["VILLE DE NAISSANCE"],
              row["ADRESSE POSTALE"], row["NUMERO DE TELEPHONE"], row["CONTACT URGENCE"], row["CONTACT URGENCE TELEPHONE"],
              row["CLASSE"], row["SPECIALISATION"]))


        student_id = cursor.fetchone()[0]

        cursor.execute("""
            INSERT INTO public.parent (student_id, nom, mot_de_passe)
            VALUES (%s, %s, %s)
        """, (student_id, row["NOM"], 'generate_random_password()'))

    connection.commit()
    connection.close()

#Fonction pour supprimer un étudiant
def delete_student_by_id(id):
    connection = create_db_connection()
    cursor = connection.cursor()

    cursor.execute(f'DELETE FROM public.parent WHERE student_id = {id};')

    cursor.execute(f'DELETE FROM public.etudiants WHERE id = {id};')

    connection.commit()
    connection.close()


    

def main():
    st.title("Liste des Étudiants")

    student_data = get_student_data_from_db()

    st.table(student_data)
    
    recherche = st.text_input('Recherche par ID')
    add_button = st.button('Rechercher')

    if add_button:
        if recherche: 
            result_data = get_student_data_by_id(recherche)
            st.table(result_data)
        else:
            st.warning("Veuillez entrer un ID pour effectuer la recherche.")
            
    st.title("Ajout d'étudiants")

    nom = st.text_input('NOM:')
    prenom = st.text_input('PRENOM:')
    date_naissance = st.text_input('DATE DE NAISSANCE:')
    ville_naissance = st.text_input('VILLE DE NAISSANCE:')
    adresse = st.text_input('ADRESSE POSTALE:')
    telephone = st.text_input('NUMERO DE TELEPHONE:')
    contact_urgent = st.text_input('CONTACT URGENCE:')
    contact_urgence_telephone = st.text_input('CONTACT URGENCE TELEPHONE:')
    classe = st.text_input('CLASSE:')
    specialisation = st.text_input('SPECIALISATION:')
    add_button2 = st.button('Ajouter')

    if add_button2:
        new_data = pd.DataFrame({
            "NOM": [nom],
            "PRENOM": [prenom],
            "DATE DE NAISSANCE": [date_naissance],
            "VILLE DE NAISSANCE": [ville_naissance],
            "ADRESSE POSTALE": [adresse],
            "NUMERO DE TELEPHONE": [telephone],
            "CONTACT URGENCE": [contact_urgent],
            "CONTACT URGENCE TELEPHONE": [contact_urgence_telephone],
            "CLASSE": [classe],
            "SPECIALISATION": [specialisation]
        })
        add_student_data_to_db(new_data)
        st.success("Etudiant ajouté avec succès")
        st.experimental_rerun()
        
    st.title("Suppression d'étudiants")
    
    id_a_supprimer = st.text_input("Entrer l'identifiant de l'élève à supprimer")
    add_button3 = st.button('Supprimer')
    
    if add_button3 : 
        delete_student_by_id(id_a_supprimer)
        st.success("Etudiant supprimé avec succès")
        st.experimental_rerun()
    
if __name__ == "__main__":
    main()
