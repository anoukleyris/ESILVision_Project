#Excatement la même idée que Porfil.py mais dans le cas général avec sélection d'un id dans le main

import streamlit as st
import pandas as pd
import psycopg2
from sqlalchemy import create_engine
import matplotlib.pyplot as plt

# Etablir la connexion à la base de données PostgreSQL
def create_db_connection():
    connection = psycopg2.connect( 
        host="localhost",
        database="ESILVision",
        user="postgres",
        password="zaL2520"
    )
    return connection

def get_document(id):
    connection = create_db_connection()
    query = f"SELECT * FROM pdf_documents WHERE etudiant_id={id};"
    document_data = pd.read_sql_query(query, connection)
    connection.close()
    return document_data

def get_student_data_by_id(id): 
    connection = create_db_connection()
    query = f"SELECT * FROM etudiants WHERE id = '{id}';" 
    student_data = pd.read_sql_query(query, connection)
    connection.close()
    return student_data

def get_student_notes_by_id(id):
    connection = create_db_connection()
    query = f"SELECT numero_controle, cours_title, note, coefficient FROM public.notes WHERE etudiant_id = {id};"
    notes_data = pd.read_sql_query(query, connection)
    connection.close()
    return notes_data

def show_notes_chart(notes_data):
    unique_courses = notes_data['cours_title'].unique()

    for course in unique_courses:
        course_data = notes_data[notes_data['cours_title'] == course]

        fig, ax = plt.subplots()
        ax.plot(course_data['numero_controle'], course_data['note'], marker='o', linestyle='-', color='b')
        ax.set_xlabel('Numéro de Contrôle')
        ax.set_ylabel('Note')
        ax.set_title(f'Notes de l\'élève pour le cours {course}')

        # Définir les numéros de contrôle comme ticks sur l'axe des abscisses
        ax.set_xticks(course_data['numero_controle'])

        st.pyplot(fig)

def show_notes_table(notes_data):
    unique_courses = notes_data['cours_title'].unique()

    for course in unique_courses:
        st.subheader(f'Matière: {course}')

        course_data = notes_data[notes_data['cours_title'] == course]
        course_data = course_data.sort_values(by='numero_controle')

        # Afficher les données dans un tableau
        st.table(course_data[['numero_controle', 'note', 'coefficient']].reset_index(drop=True))

        # Calculer la moyenne
        average = course_data['note'].mean()

        # Afficher la moyenne
        st.write(f'Moyenne pour {course}: {average:.2f}')   


def main():
    recherche = st.text_input('Recherche par ID')
    add_button = st.button('Rechercher')

    if add_button:
        if recherche:  # Check if recherche is not empty
            result_data = get_student_data_by_id(recherche)
            st.table(result_data)
            
            # Extraction des valeurs scalaires du DataFrame result_data
            prenom = result_data.iloc[0]['prenom']
            nom = result_data.iloc[0]['nom']
            
            document_data = get_document(recherche)
            st.title(f"Profil de {prenom} {nom}")
            st.title(f"Documents de {prenom} {nom}")
            
            # Ajouter la colonne avec les liens vers les fichiers PDF
            st.markdown("### Liens vers les fichiers PDF en ligne :")
            for index, row in document_data.iterrows():
                # Formater le lien en Markdown avec Streamlit
                pdf_link = f"{row['file_path']}"
                st.markdown(pdf_link, unsafe_allow_html=True)
            
            notes_data = get_student_notes_by_id(recherche)
            st.title(f"Progression de {prenom} {nom}")
            show_notes_chart(notes_data)
            show_notes_table(notes_data)            
        else:
            st.warning("Veuillez entrer un ID pour effectuer la recherche.")

if __name__ == "__main__":
    main()
