import streamlit as st
import pandas as pd
import psycopg2
from sqlalchemy import create_engine

# Etablir la connexion à la base de données PostgreSQL
def create_db_connection():
    connection = psycopg2.connect( 
        host="localhost",
        database="ESILVision",
        user="postgres",
        password="zaL2520"
    )
    return connection

def add_avis_prof(new_data):
    connection = create_db_connection()
    cursor = connection.cursor()

    for index, row in new_data.iterrows():
        cursor.execute("""
            INSERT INTO avis_prof (avis, email)
            VALUES (%s, %s)
        """, (row["AVIS"], row["EMAIL"]))

    connection.commit()
    connection.close()


def add_avis_cours(new_data):
    connection = create_db_connection()
    cursor = connection.cursor()

    for index, row in new_data.iterrows():
        cursor.execute("""
            INSERT INTO avis_course (avis, cours)
            VALUES (%s, %s)
        """, (row["AVIS"], row["COURS"]))

    connection.commit()
    connection.close()


def get_avis_prof():
    connection = create_db_connection()
    query = "SELECT * FROM avis_prof;"
    student_data = pd.read_sql_query(query, connection)
    connection.close()
    return student_data

def get_avis_cours():
    connection = create_db_connection()
    query = "SELECT * FROM avis_course;"
    student_data = pd.read_sql_query(query, connection)
    connection.close()
    return student_data

def main():
    st.title("Donne ton avis !")

    st.title("Avis sur les cours")

    avis = st.text_input('AVIS:', key='avis_cours')
    cours = st.text_input('COURS:', key='cours')
    add_button_cours = st.button('Ajouter (Avis Cours)', key='add_button_cours')

    if add_button_cours:
        new_data = pd.DataFrame({
            "AVIS": [avis],
            "COURS": [cours] 
        })
        add_avis_cours(new_data)
        st.success("Avis sur les cours pris en compte !")
        st.experimental_rerun()

    st.title("Avis sur les professeurs")

    avis = st.text_input('AVIS:', key='avis_prof')
    email = st.text_input('EMAIL:', key='prof')
    add_button_prof = st.button('Ajouter (Avis Professeur)', key='add_button_prof')

    if add_button_prof:
        new_data = pd.DataFrame({
            "AVIS": [avis],
            "EMAIL": [email] 
        })
        add_avis_prof(new_data)
        st.success("Avis sur les professeurs pris en compte !")
        st.experimental_rerun()

    st.title("Avis sur les Professeurs et les Cours")

    # Charger les données depuis la base de données PostgreSQL
    prof_avis = get_avis_prof()
    cours_avis = get_avis_cours()

    # Afficher les avis des professeurs
    st.header("Avis des Professeurs :")

    profs = prof_avis['email'].unique()
    for prof in profs:
        avis_prof = prof_avis[prof_avis['email'] == prof]['avis']
        st.subheader(f"{prof} :")
        for avis in avis_prof:
            st.write(f"   {avis}")

    # Afficher les avis des cours
    st.header("Avis des Cours :")

    cours = cours_avis['cours'].unique()
    for cours_title in cours:
        avis_cours = cours_avis[cours_avis['cours'] == cours_title]['avis']
        st.subheader(f"{cours_title} :")
        for avis in avis_cours:
            st.write(f"   {avis}")
            
            
if __name__ == "__main__":
    main()
