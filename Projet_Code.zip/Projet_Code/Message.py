import streamlit as st
import pandas as pd
import psycopg2
from sqlalchemy import create_engine

# Etablir la connexion à la base de données PostgreSQL
def create_db_connection():
    connection = psycopg2.connect( 
        host="localhost",
        database="ESILVision",
        user="postgres",
        password="zaL2520"
    )
    return connection

#Fonciton pour écrire un message
def add_message(new_data):
    connection = create_db_connection()
    cursor = connection.cursor()

    for index, row in new_data.iterrows():
        cursor.execute("""
            INSERT INTO public.message_admin (message, classe)
            VALUES (%s, %s)
        """, (row["MESSAGE"], row["CLASSE"]))

    connection.commit()
    connection.close()


def main():
    
    st.title("Message")
    
    message = st.text_input('MESSAGE:')
    classe = st.text_input('CLASSE:')
    add_button_cours = st.button('Envoyer')
    
    if add_button_cours:
        new_data = pd.DataFrame({
            "MESSAGE": [message],
            "CLASSE": [classe] 
        })
        add_message(new_data)
        st.success(f"Message envoyé à la classe {classe}!")
        st.experimental_rerun()
        
if __name__ == "__main__":
    main()
