import streamlit as st
import pandas as pd
import psycopg2

# Etablir la connexion à la base de données PostgreSQL
def create_db_connection():
    connection = psycopg2.connect( 
        host="localhost",
        database="ESILVision",
        user="postgres",
        password="zaL2520"
    )
    return connection

#Fonction pour ajouter des annonces pour une classe
def send_announcement(title, content, selected_groups):
    connection = create_db_connection()
    cursor = connection.cursor()

    cursor.execute("""
        INSERT INTO announcements (title, content, user_id)
        VALUES (%s, %s, %s)
        RETURNING id;
    """, (title, content, 1))

    announcement_id = cursor.fetchone()[0]

    for group_id in selected_groups:
        cursor.execute("""
            INSERT INTO announcement_groups (announcement_id, group_id)
            VALUES (%s, %s);
        """, (announcement_id, group_id))

    connection.commit()
    connection.close()

#Fonction pour récupérer toutes les informations d'une classe
def get_groups():
    connection = create_db_connection()
    query = "SELECT * FROM classe;" 
    groups_data = pd.read_sql_query(query, connection)
    connection.close()
    return groups_data

#Fonction pour envoyer l'annonce aux élèves d'une classe
def send_announcement_page():
    st.title("Envoyer une annonce")
    
    title = st.text_input('Titre de l\'annonce:')
    content = st.text_area('Contenu de l\'annonce:')
    groups = get_groups()
    selected_groups = st.multiselect('Sélectionner les groupes', groups['name'])

    send_button = st.button('Envoyer l\'annonce')

    if send_button:
        send_announcement(title, content, selected_groups)
        st.success("Annonce envoyée avec succès")



def main():
    st.title("Tableau de bord de l'administrateur")


    if st.sidebar.button("Envoyer une annonce"):
        send_announcement_page()



if __name__ == "__main__":
    main()
