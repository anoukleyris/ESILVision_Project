import streamlit as st
import pandas as pd
import psycopg2

# Etablir la connexion à la base de données PostgreSQL
def create_db_connection():
    connection = psycopg2.connect( 
        host="localhost",
        database="ESILVision",
        user="postgres",
        password="zaL2520"
    )
    return connection

#Fonction pour récupérer la classe d'un étudiant
def get_student_classe(id):
    connection = create_db_connection()
    query = f"SELECT classe FROM public.etudiants WHERE id = {id};"
    student_classe = pd.read_sql_query(query, connection)
    connection.close()
    return student_classe.iloc[0]['classe']

#Fonction pour récupérer le message et sa date d'envoi
def get_messages(classe):
    connection = create_db_connection()
    query = f"SELECT message, date_envoi FROM message_admin WHERE classe = '{classe}' ORDER BY date_envoi DESC;"
    messages = pd.read_sql_query(query, connection)
    connection.close()
    return messages

def main(id):
    st.title("Messages de l'administration")
    
    classe_etudiant = get_student_classe(id)
    
    messages = get_messages(classe_etudiant)
    
    if not messages.empty: #si un message a été envoyé à la classe de l'élève, il peut le visualiser
        for _, row in messages.iterrows():
            formatted_date = row['date_envoi'].strftime("**%Y-%m-%d**")
            st.markdown(f"{formatted_date} : {row['message']}")
    else:
        st.write("Aucun message pour votre classe actuellement.")

if __name__ == "__main__":
    main(id)







