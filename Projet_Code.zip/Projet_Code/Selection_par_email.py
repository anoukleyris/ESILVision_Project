import streamlit as st
import pandas as pd
import psycopg2

# Etablir la connexion à la base de données PostgreSQL
def create_db_connection():
    connection = psycopg2.connect( 
        host="localhost",
        database="ESILVision",
        user="postgres",
        password="zaL2520"
    )
    return connection

#Fonction pour récupérr les emails et noms complets des professeurs d'un cours
def liste_profs(cours):
    connection = create_db_connection()  
    query = f"SELECT email, prenom || ' ' || nom AS full_name FROM public.prof WHERE cours_title = '{cours}';"  
    student_data = pd.read_sql_query(query, connection)  
    connection.close()  
    return student_data[["email", "full_name"]].values.tolist() 

def main():
    cours = st.text_input("Entrer le titre du cours")
    add_button = st.button('Afficher la liste')

    if add_button:
        if cours:  
            st.title(f"Liste des professeurs pour le cours {cours}")
            result_data = liste_profs(cours)
            for teacher in result_data:
                st.write(f"{teacher[0]}, {teacher[1]}")  # Afficher chaque professeur avec email et full_name
        else:
            st.warning("Veuillez entrer un ID pour effectuer la recherche.")

if __name__ == "__main__":
    main()