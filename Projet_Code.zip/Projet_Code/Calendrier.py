import streamlit as st
import calendar
import pandas as pd
import psycopg2

# Etablir la connexion à la base de données PostgreSQL
def create_db_connection():
    connection = psycopg2.connect( 
        host="localhost",
        database="ESILVision",
        user="postgres",
        password="zaL2520"
    )
    return connection

# Fonction pour récupérer les événements
def get_events(year, month):
    connection = create_db_connection()
    query = """
    SELECT title, start_date, end_date, description 
    FROM public.events 
    WHERE EXTRACT(YEAR FROM start_date) = %s AND EXTRACT(MONTH FROM start_date) = %s;
    """
    events_df = pd.read_sql(query, connection, params=(year, month))
    connection.close()
    return events_df

# Fonction pour récupérer les jours fériés
def get_holidays(year, month):
    connection = create_db_connection()
    query = """
    SELECT name, start_date, end_date 
    FROM public.holidays 
    WHERE EXTRACT(YEAR FROM start_date) = %s AND EXTRACT(MONTH FROM start_date) = %s;
    """
    holidays_df = pd.read_sql(query, connection, params=(year, month))
    connection.close()
    return holidays_df

#Fonction pour connaître la "nature du jour"
def get_day_category(day, month, year, events, holidays):
    current_date = pd.Timestamp(year, month, day).date()  # Convertir en datetime.date

    for _, event in events.iterrows():
        event_start = event['start_date']
        event_end = event['end_date']
        if event_start <= current_date <= event_end:
            return 'event'
    
    for _, holiday in holidays.iterrows():
        holiday_start = holiday['start_date']
        holiday_end = holiday['end_date']
        if holiday_start <= current_date <= holiday_end:
            return 'holiday'

    return 'normal'
#à reprendre pour que ça marche sur plusieurs mois de plusieurs années 


#Fonction pour créer le calendrier
def generate_calendar_html(year, month, events, holidays):
    cal = calendar.monthcalendar(year, month)
    days_of_week = list(calendar.day_abbr)

    calendar_html = "<table class='calendar'>\n" #création d'un calendrier 
    calendar_html += "<tr>" + "".join(f"<th class='calendar-header'>{day}</th>" for day in days_of_week) + "</tr>\n" #permet de créer une en-tête pour chaque jour

    for week in cal: #pour chaque semaine :
        calendar_html += "<tr>" #rajoute une ligne pour cahque semaine
        for day in week: #pour chaque jour de la semaine :
            day_content = day if day != 0 else ""
            day_category = get_day_category(day, month, year, events, holidays) if day_content else "normal" #utilise la fonction get_day_category() pour connaître la "nature du jour"
            if day_category == 'event': #les évènements seront en rose
                color = 'violet' 
            elif day_category == 'holiday': #les vacances seront en vertes
                color = 'lightgreen' 
            else: #les autres jours ne sont pas colorés
                color = 'white'
            calendar_html += f"<td class='calendar-day' style='background-color: {color};'>{day_content}</td>" #associe à chaque jour sa couleur
        calendar_html += "</tr>\n" 

    calendar_html += "</table>"
    return calendar_html



def main():
    st.title("ACCUEIL")

    year_to_display = st.selectbox('Choisissez l\'année', list(range(2020, 2031)), index=3)
    month_to_display = st.selectbox('Choisissez le mois', list(range(1, 13)))

    events_data = get_events(year_to_display, month_to_display)
    holidays_data = get_holidays(year_to_display, month_to_display)
    add_button = st.button('Afficher')

    if add_button :
        calendar_html = generate_calendar_html(year_to_display, month_to_display, events_data, holidays_data)
        st.markdown(calendar_html, unsafe_allow_html=True)

        st.markdown("""
            <style>
            .calendar {
                width: 100%;
                border-collapse: collapse;
            }
            .calendar-header {
                background-color: gray;
                color: white;
            }
            .calendar-day {
                text-align: center;
                vertical-align: middle;
                height: 50px;
            }
            </style>
        """, unsafe_allow_html=True)

if __name__ == "__main__":
    main()