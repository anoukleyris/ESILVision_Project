import streamlit as st
import pandas as pd
import psycopg2

# Etablir la connexion à la base de données PostgreSQL
def create_db_connection():
    connection = psycopg2.connect( 
        host="localhost",
        database="ESILVision",
        user="postgres",
        password="zaL2520"
    )
    return connection

#Fonction pour récupérr les id et noms complets des étudiants d'une classe
def liste_eleves(classe):
    connection = create_db_connection()  
    query = f"SELECT id, prenom || ' ' || nom AS full_name FROM public.etudiants WHERE classe = '{classe}';"  
    student_data = pd.read_sql_query(query, connection)  
    connection.close() 
    return student_data[["id", "full_name"]].values.tolist()  

def main():
    classe = st.text_input("Entrer le nom de la classe")
    add_button = st.button('Afficher la liste')

    if add_button:
        if classe:  
            result_data = liste_eleves(classe)
            for student in result_data:
                st.write(f"{student[0]}, {student[1]}")  # Afficher chaque étudiant avec id et full_name
        else:
            st.warning("Veuillez entrer un ID pour effectuer la recherche.")

if __name__ == "__main__":
    main()
